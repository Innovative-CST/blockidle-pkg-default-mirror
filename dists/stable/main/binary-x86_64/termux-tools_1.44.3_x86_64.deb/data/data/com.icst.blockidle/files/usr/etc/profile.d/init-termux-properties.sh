if [ ! -f /data/data/com.icst.android.appstudio/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.icst.android.appstudio/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.icst.android.appstudio/files/home/.termux
	cp /data/data/com.icst.android.appstudio/files/usr/share/examples/termux/termux.properties /data/data/com.icst.android.appstudio/files/home/.termux/
fi
