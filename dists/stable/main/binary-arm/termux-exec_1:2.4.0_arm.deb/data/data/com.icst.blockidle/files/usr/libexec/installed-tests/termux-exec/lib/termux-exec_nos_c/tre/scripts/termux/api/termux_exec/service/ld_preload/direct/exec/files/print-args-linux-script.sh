#!/data/data/com.icst.blockidle/files/usr/bin/sh

echo "$@"
